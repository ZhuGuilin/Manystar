//
// Created by zgl on 04/02/2021.
//

#include "Worker.h"
#include "ServerConf.h"
#include "Monitor.h"
#include "module/ModuleManager.h"
#include "base/Util.h"


namespace manystar {

static Worker* s_worker = nullptr;
static int s_workerWeight[] =
{
    -1, -1, -1, -1,
    0, 0, 0, 0,
    1, 1, 1, 1,
    2, 2, 2, 2
};

Worker::Worker()
:_exit(false)
{

}

Worker::~Worker()
{

}

Worker& Worker::instance()
{
    if (nullptr == s_worker)
    {
        s_worker = new Worker;
    }

    return *s_worker;
}

void Worker::Setup()
{
    uint32_t workerNum = ServerConf::instance().ThreadNum();
    int WEIGHT_NUM = sizeof(s_workerWeight) / sizeof(s_workerWeight[0]);
    for (int i = 0; i < workerNum; ++i)
    {
        _workers.push_back(std::thread([=] {
            auto& monitor = Monitor::instance();
            int weight = i < WEIGHT_NUM ? s_workerWeight[i] : 0;
            while (!_exit.load())
            {
                Process(weight);
                if (_tasks.empty())
                {
                    monitor.SleepCounter();

                    if (!_exit.load())
                    {
                        std::unique_lock<std::mutex> lock(_mutex);
                        _ready.wait(lock);
                    }

                    monitor.WakeupCounter();
                }
            }
        }));
    }

    for (auto& worker : _workers)
    {
        worker.join();
    }
}

void Worker::AddTask(uint32_t task) noexcept
{
    _tasks.push(std::move(task));
    _ready.notify_one();
}

void Worker::Process(int weight)
{
    auto task = _tasks.pop();
    auto context = ModuleManager::instance().Find(task);
    if (nullptr == context)
    {
        if (0 != task)
        {
            fprintf(stderr, "woker process err, cannot find context<%d>.\n", task);
        }
        return;
    }

    int n = 1;
    for (int i = 0; i < n; ++i)
    {
        auto msg = context->msges.pop();
        if (context->profile)
        {
            auto start = Util::steady_microseconds();
            context->module->Callback(context, std::move(msg));
            context->cpuCost += Util::steady_microseconds() - start;
        }
        else
        {
            context->module->Callback(context, std::move(msg));
        }

        if (0 == i && weight >= 0)
        {
            n = (int)context->msges.size();
            n >>= weight;
        }

        ++context->msgCount;
    }

    context->inGlobal.store(false);
    if (!context->msges.empty())
    {
        if (!context->inGlobal.exchange(true))
        {
            AddTask(context->handle);
        }
    }
}

void Worker::Quit()
{
    _exit.store(true);
    _ready.notify_all();
}

}