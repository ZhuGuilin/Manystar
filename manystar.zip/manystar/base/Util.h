//
// Created by zgl on 20/01/2021.
//

#ifndef MANYSTAR_UTIL_H
#define MANYSTAR_UTIL_H

#include <vector>
#include <string>


namespace manystar {

class Util
{
public:

    static std::string format(const char *fmt, ...);

    static void split(std::vector<std::string>& v, std::string& s, const char* c);

    static std::string& Lower(std::string& str);

    static int64_t atoi(const char *c, const char *e) noexcept;

    static int64_t atoi(const char *c) noexcept;

    static uint64_t system_milliseconds() noexcept;

    static uint64_t steady_milliseconds() noexcept;

    static uint64_t steady_microseconds() noexcept;

    static std::string system_date();

    static bool mkDir(const char* dirPath);

    static bool delFile(const char* fileName);
};

template <class T>
inline const T& min(const T& a, const T& b)
{
    return b < a ? b : a;
}

template <class T>
inline const T& max(const T& a, const T& b)
{
    return a < b ? b : a;
}

}

#endif //MANYSTAR_UTIL_H
