//
// Created by zgl on 20/01/2021.
//

#ifndef MANYSTAR_EXITCALLER_H
#define MANYSTAR_EXITCALLER_H

#include <functional>
#include "Noncopyable.h"


namespace manystar {

class ExitCaller : private noncopyable
{
public:

    ExitCaller(std::function<void()> &&func)
            : _func(std::move(func))
    {
    }

    virtual ~ExitCaller()
    {
        _func();
    }

private:

    std::function<void()>	_func;
};

}

#endif //MANYSTAR_EXITCALLER_H
