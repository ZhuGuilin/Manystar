//
// Created by zgl on 04/02/2021.
//

#ifndef MANYSTAR_CONFIG_H
#define MANYSTAR_CONFIG_H

#include <map>
#include <string>


namespace manystar {

class Config
{
public:

    Config(const char* name);

    std::string Find(const char* key);
    int Find(const char* key, int def);
    double Find(const char* key, double def);

private:

    bool parse(const char* name);
    std::map<std::string, std::string>  _confs;
};

}

#endif //MANYSTAR_CONFIG_H
