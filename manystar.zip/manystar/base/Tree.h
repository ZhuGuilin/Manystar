//
// Created by zgl on 20/01/2021.
//

#ifndef MANYSTAR_TREE_H
#define MANYSTAR_TREE_H

#define TREE_DEFAULT_RESERVE	32	// By default, trees reserve enough space, in advance, for this many nodes.


namespace manystar {

template<typename T>
class Tree
{
public:

    enum COLOR
    {
        red,
        black
    };

    struct Node
    {
        COLOR		color;
        T           key;
        union {
            Node*	left;
            Node*	next;
        };
        Node*		parent;
        Node*		right;
    };

    struct Chunk
    {
        Chunk*		next;
        Node*		nodes;
    };

    // Constructor
    Tree()
    {
        _freelist = nullptr;
        _nil.color = black;
        _nil.key = T();
        _nil.left = &_nil;
        _nil.parent = &_nil;
        _nil.right = &_nil;
        _reserve = TREE_DEFAULT_RESERVE;
        _root = &_nil;
        _store = nullptr;
        _storetail = nullptr;
    }

    Tree(const Tree& source)
    {
    }

    // Destructor
    ~Tree()
    {
        Chunk *cur;
        Chunk *temp;

        // Free all the chunks in the chunk list.
        cur = _store;
        while (cur != nullptr)
        {
            temp = cur;
            cur = cur->next;
            delete[] temp->nodes;
            delete temp;
        }
    }

    Tree<T>& operator =(const Tree<T> &other)
    {
        return *this;
    }

    typename Tree::Node* begin() const
    {
        Node* cur;
        if (_root == &_nil)
        {
            return nullptr;
        }

        cur = _root;
        while (cur->left != &_nil)
        {
            cur = cur->left;
        }

        return cur;
    }

    void erase(typename Tree::Node* node)
    {
        Node* child;
        Node* cur;
        Node* erasure;
        Node* sibling;

        if ((node->left == &_nil) || (node->right == &_nil))
        {
            erasure = node;
        }
        else
        {
            erasure = node->right;
            while (erasure->left != &_nil)
            {
                erasure = erasure->left;
            }
        }

        if (erasure->left != &_nil)
        {
            child = erasure->left;
        }
        else
        {
            child = erasure->right;
        }

        child->parent = erasure->parent;
        if (child->parent == &_nil)
        {
            _root = child;
        }
        else
        {
            if (erasure == erasure->parent->left)
            {
                erasure->parent->left = child;
            }
            else
            {
                erasure->parent->right = child;
            }
        }

        if (erasure != node)
        {
            node->key = erasure->key;
        }

        if (erasure->color == black)
        {
            cur = child;
            while ((cur != _root) && (cur->color == black))
            {
                if (cur == cur->parent->left)
                {
                    sibling = cur->parent->right;
                    if (sibling->color == red)
                    {
                        sibling->color = black;
                        cur->parent->color = red;
                        Rotateleft(cur->parent);
                        sibling = cur->parent->right;
                    }
                    if ((sibling->left->color == black) && (sibling->right->color == black))
                    {
                        sibling->color = red;
                        cur = cur->parent;
                    }
                    else
                    {
                        if (sibling->right->color == black)
                        {
                            sibling->left->color = black;
                            sibling->color = red;
                            Rotateright(sibling);
                            sibling = cur->parent->right;
                        }
                        sibling->color = cur->parent->color;
                        cur->parent->color = black;
                        sibling->right->color = black;
                        Rotateleft(cur->parent);
                        cur = _root;
                    }
                }
                else
                {
                    sibling = cur->parent->left;
                    if (sibling->color == red)
                    {
                        sibling->color = black;
                        cur->parent->color = red;
                        Rotateright(cur->parent);
                        sibling = cur->parent->left;
                    }
                    if ((sibling->left->color == black) && (sibling->right->color == black))
                    {
                        sibling->color = red;
                        cur = cur->parent;
                    }
                    else
                    {
                        if (sibling->left->color == black)
                        {
                            sibling->right->color = black;
                            sibling->color = red;
                            Rotateleft(sibling);
                            sibling = cur->parent->left;
                        }
                        sibling->color = cur->parent->color;
                        cur->parent->color = black;
                        sibling->left->color = black;
                        Rotateright(cur->parent);
                        cur = _root;
                    }
                }
            }
            cur->color = black;
        }

        erasure->next = _freelist;
        _freelist = erasure;
    }

    void erase(const T& key)
    {
        Node* node = _root;
        while (node != &_nil)
        {
            if (node->key < key)
            {
                node = node->right;
            }
            else if (key < node->key)
            {
                node = node->left;
            }
            else
            {
                erase(node);
                return;
            }
        }
    }

    typename Tree::Node* find(const T& key) const
    {
        Node* cur = _root;
        while (cur != &_nil)
        {
            if (cur->key < key)
            {
                cur = cur->right;
            }
            else if (key < cur->key)
            {
                cur = cur->left;
            }
            else
            {
                return cur;
            }
        }
        return nullptr;
    }

    typename Tree::Node* insert(const T& key)
    {
        Node* cur = _root;
        Node* parent = &_nil;
        while (cur != &_nil)
        {
            parent = cur;
            if (cur->key < key)
            {
                cur = cur->right;
            }
            else if (key < cur->key)
            {
                cur = cur->left;
            }
            else
            {
                return nullptr;
            }
        }

        if (_freelist == nullptr)
        {
            reserve(_reserve);
        }

        Node* node = _freelist;
        _freelist = _freelist->next;

        node->color = red;
        node->key = key;
        node->left = &_nil;
        node->parent = parent;
        node->right = &_nil;
        if (parent == &_nil)
        {
            _root = node;
        }
        else
        {
            if (parent->key < key)
            {
                parent->right = node;
            }
            else
            {
                parent->left = node;
            }
        }

        cur = node;
        Node* uncle;
        while (cur->parent->color == red)
        {
            if (cur->parent == cur->parent->parent->left)
            {
                uncle = cur->parent->parent->right;
                if (uncle->color == red)
                {
                    cur->parent->parent->color = red;
                    cur->parent->color = black;
                    uncle->color = black;
                    cur = cur->parent->parent;
                }
                else
                {
                    if (cur == cur->parent->right)
                    {
                        cur = cur->parent;
                        Rotateleft(cur);
                    }
                    cur->parent->color = black;
                    cur->parent->parent->color = red;
                    Rotateright(cur->parent->parent);
                }
            }
            else
            {
                uncle = cur->parent->parent->left;
                if (uncle->color == red)
                {
                    cur->parent->parent->color = red;
                    cur->parent->color = black;
                    uncle->color = black;
                    cur = cur->parent->parent;
                }
                else
                {
                    if (cur == cur->parent->left)
                    {
                        cur = cur->parent;
                        Rotateright(cur);
                    }
                    cur->parent->color = black;
                    cur->parent->parent->color = red;
                    Rotateleft(cur->parent->parent);
                }
            }
        }

        _root->color = black;
        return node;
    }

    typename Tree::Node* next(typename Tree::Node* node) const
    {
        if (node == nullptr)
        {
            return nullptr;
        }

        Node* cur;
        if (node->right != &_nil)
        {
            cur = node->right;
            while (cur->left != &_nil)
            {
                cur = cur->left;
            }
            return cur;
        }
        else if (node->parent != &_nil)
        {
            if (node == node->parent->left)
            {
                return node->parent;
            }
            else
            {
                cur = node;
                while (cur->parent != &_nil)
                {
                    if (cur == cur->parent->right)
                    {
                        cur = cur->parent;
                        continue;
                    }
                    else
                    {
                        return cur->parent;
                    }
                }
                return nullptr;
            }
        }
        else
        {
            return nullptr;
        }
    }

    typename Tree::Node* prev(typename Tree::Node* node) const
    {
        if (node == nullptr)
        {
            return nullptr;
        }

        Node* cur;
        if (node->left != &_nil)
        {
            cur = node->left;
            while (cur->right != &_nil)
            {
                cur = cur->right;
            }

            return cur;
        }
        else if (node->parent != &_nil)
        {
            if (node == node->parent->right)
            {
                return node->parent;
            }
            else
            {
                cur = node;
                while (cur->parent != &_nil)
                {
                    if (cur == cur->parent->left)
                    {
                        cur = cur->parent;
                        continue;
                    }
                    else
                    {
                        return cur->parent;
                    }
                }
                return nullptr;
            }
        }
        else
        {
            return nullptr;
        }
    }

    uint32_t reserve(uint32_t count)
    {
        Chunk*	 chunk;
        uint32_t   index;
        uint32_t   oldreserve = _reserve;

        if (count != _reserve)
        {
            if (count < 1)
            {
                _reserve = 1;
            }
            else
            {
                _reserve = count;
            }
        }

        if (_freelist == nullptr)
        {
            chunk = new Tree::Chunk;
            chunk->nodes = new Tree::Node[_reserve];
            chunk->next = nullptr;
            if (_store == nullptr)
            {
                _store = chunk;
            }
            else
            {
                _storetail->next = chunk;
            }
            _storetail = chunk;

            for (index = 0; index < _reserve - 1; index++)
            {
                chunk->nodes[index].next = &chunk->nodes[index + 1];
            }
            chunk->nodes[index].next = nullptr;
            _freelist = chunk->nodes;
        }

        return oldreserve;
    }

private:

    void Rotateleft(typename Tree::Node* parent) noexcept
    {
        Node* child = parent->right;

        parent->right = child->left;
        if (child->left != &_nil)
        {
            child->left->parent = parent;
        }

        child->parent = parent->parent;
        if (parent->parent == &_nil)
        {
            _root = child;
        }
        else
        {
            if (parent == parent->parent->left)
            {
                parent->parent->left = child;
            }
            else
            {
                parent->parent->right = child;
            }
        }
        child->left = parent;
        parent->parent = child;
    }

    void Rotateright(typename Tree::Node* parent) noexcept
    {
        Node* child = parent->left;

        parent->left = child->right;
        if (child->right != &_nil)
        {
            child->right->parent = parent;
        }

        child->parent = parent->parent;
        if (parent->parent == &_nil)
        {
            _root = child;
        }
        else
        {
            if (parent == parent->parent->left)
            {
                parent->parent->left = child;
            }
            else
            {
                parent->parent->right = child;
            }
        }

        child->right = parent;
        parent->parent = child;
    }

private:

    Node*		    _freelist;
    Node		    _nil;
    Node*		    _root;
    Chunk*		    _store;
    Chunk*		    _storetail;
    uint32_t        _reserve;
};

}

#endif //MANYSTAR_TREE_H
