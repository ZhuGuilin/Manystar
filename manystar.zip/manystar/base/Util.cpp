//
// Created by zgl on 20/01/2021.
//

#include <algorithm>
#include <functional>
#include <stdarg.h>
#include <memory>
#include <cstring>
#include <chrono>
#include <ftw.h>
#include "Util.h"


namespace manystar {

std::string Util::format(const char *fmt, ...)
{
    char buffer[512] = { 0 };
    std::unique_ptr<char[]> release;
    char* base = nullptr;
    for (int iter = 0; iter < 2; iter++)
    {
        int bufsize = 0;
        if (iter == 0)
        {
            bufsize = sizeof(buffer);
            base = buffer;
        }
        else
        {
            bufsize = 4096;
            base = new char[bufsize];
            release.reset(base);
        }

        char *p = base;
        char *limit = base + bufsize;
        if (p < limit)
        {
            va_list ap;
            va_start(ap, fmt);
            p += vsnprintf(p, limit - p, fmt, ap);
            va_end(ap);
        }

        // Truncate to available space if necessary
        if (p >= limit)
        {
            if (iter == 0)
            {
                continue;  // Try again with larger buffer
            }
            else
            {
                p = limit - 1;
                *p = '\0';
            }
        }
        break;
    }
    return base;
}

std::string& Util::Lower(std::string& str)
{
    std::transform(str.begin(), str.end(), str.begin(), ::tolower);
    return str;
}

void Util::split(std::vector<std::string>& v, std::string& s, const char* c)
{
    v.clear();
    std::string::size_type b = 0, e = 0;
    for (;;)
    {
        b = s.find_first_not_of(c, e);
        if (std::string::npos == b)
            break;

        e = s.find_first_of(c, b);
        v.push_back(s.substr(b, e - b));

        if (std::string::npos == e)
            break;
    }
}

int64_t Util::atoi(const char *c, const char *e) noexcept
{
    return strtol(c, (char **)&e, 10);
}

int64_t Util::atoi(const char *c) noexcept
{
    return atoi(c, c + strlen(c));
}

uint64_t Util::system_milliseconds() noexcept
{
    using namespace std::chrono;
    return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}

uint64_t Util::steady_milliseconds() noexcept
{
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

uint64_t Util::steady_microseconds() noexcept
{
    using namespace std::chrono;
    return duration_cast<microseconds>(steady_clock::now().time_since_epoch()).count();
}

std::string Util::system_date()
{
    time_t t = system_milliseconds() / 1000;
    struct tm tm1;
    localtime_r(&t, &tm1);
    return format("%04d-%02d-%02d-%02d:%02d:%02d",
                  tm1.tm_year + 1900,
                  tm1.tm_mon + 1,
                  tm1.tm_mday,
                  tm1.tm_hour,
                  tm1.tm_min,
                  tm1.tm_sec);
}

bool Util::mkDir(const char* dirPath)
{
    int ret = ::mkdir(dirPath, S_IRUSR | S_IWUSR | S_IXUSR | S_IRWXG | S_IRWXO);
    if (0 == ret)
    {
        fprintf(stderr, "Create dir failed! path<%s>", dirPath);
    }

    return 0 != ret;
}

bool Util::delFile(const char* fileName)
{
    return remove(fileName) == 0;
}

}