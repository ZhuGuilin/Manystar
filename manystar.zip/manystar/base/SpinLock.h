//
// Created by zgl on 20/01/2021.
//

#ifndef MANYSTAR_SPINLOCK_H
#define MANYSTAR_SPINLOCK_H

#include <atomic>
#include <thread>
#include <emmintrin.h>


namespace manystar {

const uint32_t MAX_SPIN = 4000;
const std::chrono::nanoseconds SLEEP_NANO = std::chrono::microseconds(500);

class SpinLock
{
public:

    enum LOCK_STATUS
    {
        LS_FREE = 0,
        LS_LOCK
    };

    SpinLock() noexcept
    {
        reinterpret_cast<std::atomic<uint8_t>*>(&_lock)->store(LS_FREE);
    }

    void lock() noexcept
    {
        uint32_t count = 0;
        while (!cas(LS_FREE, LS_LOCK))
        {
            do
            {
                if (++count < MAX_SPIN)
                {
                    ::_mm_pause();
                }
                else
                {	// sleep override
                    std::this_thread::sleep_for(SLEEP_NANO);
                }
            } while (reinterpret_cast<std::atomic<uint8_t>*>(&_lock)->load(std::memory_order_relaxed) == LS_LOCK);
        }
    }

    bool trylock() noexcept
    {
        return cas(LS_FREE, LS_LOCK);
    }

    void unlock() noexcept
    {
        reinterpret_cast<std::atomic<uint8_t>*>(&_lock)->store(LS_FREE, std::memory_order_release);
    }

private:

    bool cas(uint8_t compare, uint8_t newVal) noexcept
    {
        return std::atomic_compare_exchange_strong_explicit(
                reinterpret_cast<std::atomic<uint8_t>*>(&_lock),
                &compare,
                newVal,
                std::memory_order_acquire,
                std::memory_order_relaxed);
    }

    uint8_t	_lock;
};


class SpinLockGuard
{
public:

    explicit SpinLockGuard(SpinLock& lock)
        : _splock(lock)
    {	// construct and lock
        _splock.lock();
    }

    ~SpinLockGuard() noexcept
    {	// unlock
        _splock.unlock();
    }

private:

    SpinLock& _splock;
};

}

#endif //MANYSTAR_SPINLOCK_H
