//
// Created by zgl on 21/01/2021.
//

#ifndef MANYSTAR_RWLOCK_H
#define MANYSTAR_RWLOCK_H

#include <pthread.h>


namespace manystar {

class RWLock
{
public:

    RWLock() noexcept
    {
        pthread_rwlock_init(&_rwl, NULL);
    }

    ~RWLock() noexcept
    {
        pthread_rwlock_destroy(&_rwl);
    }

    void rlock() noexcept
    {
        pthread_rwlock_rdlock(&_rwl);
    }

    void wlock() noexcept
    {
        pthread_rwlock_wrlock(&_rwl);
    }

    void unlock() noexcept
    {
        pthread_rwlock_unlock(&_rwl);
    }

private:

    pthread_rwlock_t	_rwl;
};


class ReadLockGuard
{
public:

    explicit ReadLockGuard(RWLock& lock)
       : _rwlock(lock)
    {	// construct and rlock
        _rwlock.rlock();
    }

    ~ReadLockGuard() noexcept
    {	// unlock
        _rwlock.unlock();
    }

private:

    RWLock& _rwlock;
};


class WriteLockGuard
{
public:

   explicit WriteLockGuard(RWLock& lock)
        : _rwlock(lock)
   {	// construct and wlock
        _rwlock.wlock();
   }

   ~WriteLockGuard() noexcept
   {	// unlock
       _rwlock.unlock();
   }

private:

   RWLock& _rwlock;
};

}

#endif //MANYSTAR_RWLOCK_H
