//
// Created by zgl on 21/01/2021.
//

#ifndef MANYSTAR_SIMPLEMEMORYPOOL_H
#define MANYSTAR_SIMPLEMEMORYPOOL_H

#include "Noncopyable.h"
#include "SpinLock.h"


namespace manystar {

template <class T>
class SimpleMemoryPool : private noncopyable
{
public:

    SimpleMemoryPool(uint32_t size = 64)
        :_size(size)
    {
        expand();
    }

    virtual ~SimpleMemoryPool()
    {
        SpinLockGuard lock(_splock);
        MemoryNode* node = _head;
        MemoryNode* ptr  = node;
        while (node)
        {
            node = node->next;
            delete ptr;
            ptr = node;
        }
    }

    T* malloc()
    {
        SpinLockGuard lock(_splock);
        if (nullptr == _head)
        {
            expand();
        }

        MemoryNode* node = _head;
        _head = _head->next;
        return reinterpret_cast<T*>(node->data);
    }

    void free(void* p) noexcept
    {
        SpinLockGuard lock(_splock);
        MemoryNode* node = (MemoryNode*)p;
        node->next = _head;
        _head = node;
    }

private:

    struct MemoryNode
    {
        char		data[sizeof(T)];
        MemoryNode*	next;

        MemoryNode() :data{ 0 }, next(nullptr) {}
    };

    inline void expand()
    {
        MemoryNode* node = new MemoryNode;
        _head = node;

        for (uint32_t i = 0; i < _size - 1; i++)
        {
            node->next = new MemoryNode;
            node = node->next;
        }
    }

private:

    uint32_t	    _size;
    MemoryNode*		_head;
    SpinLock		_splock;
};

}

#endif //MANYSTAR_SIMPLEMEMORYPOOL_H
