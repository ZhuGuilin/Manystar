//
// Created by zgl on 20/01/2021.
//

#ifndef MANYSTAR_NONCOPYABLE_H
#define MANYSTAR_NONCOPYABLE_H

namespace manystar {

class noncopyable
{
protected:

    noncopyable() = default;
    virtual ~noncopyable() = default;

private:

    noncopyable(const noncopyable &) = delete;
    const noncopyable &operator=(const noncopyable &) = delete;
};

}

#endif //MANYSTAR_NONCOPYABLE_H
