//
// Created by zgl on 20/01/2021.
//

#ifndef MANYSTAR_RANDOM_H
#define MANYSTAR_RANDOM_H

#include <random>
#include <memory>


namespace manystar {

class Random
{
public:

    static Random& instance() noexcept
    {
        static Random s_random;
        return s_random;
    }

    int rand(int min, int max) noexcept
    {   //  [min, max)
        std::uniform_int_distribution<int> dist(min, max - 1);
        return dist(*_dre);
    }

    double rand(double min, double max) noexcept
    {
        std::uniform_real_distribution<double> dist(min, max);
        return dist(*_dre);
    }

private:

    Random() noexcept
    {
        std::random_device rd;
        _dre = std::make_shared<std::default_random_engine>(rd());
    }

    virtual ~Random()
    {
    }

    std::shared_ptr<std::default_random_engine>	_dre;
};

#define random(a, b)	Random::instance().rand(a, b)

}

#endif //MANYSTAR_RANDOM_H
