//
// Created by zgl on 06/02/2021.
//

#ifndef MANYSTAR_HANDLEDICT_H
#define MANYSTAR_HANDLEDICT_H

#include "Noncopyable.h"
#include "RWLock.h"


namespace manystar {

template <class T>
class HandleDict : private noncopyable
{
public:

    HandleDict(uint32_t SIZE = 32)
    :_index(1)  //  0 is reserved
    ,_count(0)
    ,_length(SIZE)
    {
        WriteLockGuard wlock(_rwlock);
        _table = new T[_length]();
    }

    virtual ~HandleDict()
    {
        WriteLockGuard wlock(_rwlock);
        free();
    }

    uint32_t insert(const T v) noexcept
    {
        WriteLockGuard wlock(_rwlock);
        if (_count == _length)
        {
            expand();
        }

        uint32_t key = 0;
        for (uint32_t i = 0; i < _length; ++i, ++_index)
        {
            if (0 == (key = _index % _length))
            {   //  0 is reserved
                continue;
            }

            if (nullptr == _table[key])
            {
                ++_count;
                _table[key] = v;
                _index = key + 1;
                break;
            }
        }

        return key;
    }

    T find(uint32_t key) const noexcept
    {
        if (key >= _length)
        {
            fprintf(stderr, "HandleDict find err, key<%d> length<%d>", key, _length);
            static T st = T();
            return st;
        }

        ReadLockGuard rlock(_rwlock);
        return _table[key];
    }

    T erase(uint32_t key) noexcept
    {
        if (key >= _length)
        {
            fprintf(stderr, "HandleDict erase err, key<%d> length<%d>", key, _length);
            return T();
        }

        WriteLockGuard wlock(_rwlock);
        T v = _table[key];
        _table[key] = nullptr;
        --_count;
        return v;
    }

    uint32_t size() const noexcept
    {
        ReadLockGuard rlock(_rwlock);
        return _count;
    }

private:

    inline void expand()
    {
        uint32_t size = _length;
        _length <<= 1;
        T* D = new T[_length]();
        for (uint32_t i = 0; i < size; ++i)
        {
            D[i] = _table[i];
            _table[i] = nullptr;
        }

        free();
        _table = D;
    }

    inline void free()
    {
        if (nullptr != _table)
        {
            delete[] _table;
            _table = nullptr;
        }
    }

    uint32_t    _index;
    uint32_t    _count;
    uint32_t    _length;
    T*          _table;

    mutable RWLock _rwlock;
};

}

#endif //MANYSTAR_HANDLEDICT_H
