//
// Created by root on 2021/2/15.
//

#ifndef MANYSTAR_HASHMAP_H
#define MANYSTAR_HASHMAP_H

#include <unordered_map>
#include "RWLock.h"
#include "Noncopyable.h"


namespace manystar {

template<typename K, typename T,
        typename HASH = std::hash<K>,
        typename PRED = std::equal_to<K>,
        typename ALLOC = std::allocator<std::pair<const K, T>>>
class Hashmap : private noncopyable
{
public:

    using MapType = std::unordered_map<K, T, HASH, PRED, ALLOC>;
    using KeyType = typename MapType::key_type;
    using ValueType = typename MapType::value_type;
    using MappedType = typename MapType::mapped_type;
    using SizeType = typename MapType::size_type;
    using Iterator = typename MapType::iterator;
    using ConstIterator = typename MapType::const_iterator;

    bool empty() const noexcept
    {
        ReadLockGuard rlock(_rwlock);
        return _map.empty();
    }

    SizeType size() const noexcept
    {
        ReadLockGuard rlock(_rwlock);
        return _map.size();
    }

    SizeType max_size() const noexcept
    {
        ReadLockGuard rlock(_rwlock);
        return _map.max_size();
    }

    ConstIterator begin() const noexcept
    {
        ReadLockGuard rlock(_rwlock);
        return _map.begin();
    }

    ConstIterator end() const noexcept
    {
        ReadLockGuard rlock(_rwlock);
        return _map.end();
    }

    ConstIterator cbegin() const noexcept
    {
        ReadLockGuard rlock(_rwlock);
        return _map.cbegin();
    }

    ConstIterator cend() const noexcept
    {
        ReadLockGuard rlock(_rwlock);
        return _map.cend();
    }

    std::pair<Iterator, bool> insert(const ValueType & v)
    {
        WriteLockGuard wlock(_rwlock);
        return _map.insert(v);
    }

    template<typename _Pair, typename = typename
    std::enable_if<std::is_constructible<ValueType, _Pair&&>::value>::type>
    std::pair<Iterator, bool> insert(_Pair&& p)
    {
        WriteLockGuard wlock(_rwlock);
        return _map.insert(std::forward<_Pair>(p));
    }

    ConstIterator find(const KeyType& key) const noexcept
    {
        ReadLockGuard rlock(_rwlock);
        return _map.find(key);
    }

    SizeType erase(const KeyType& key)
    {
        WriteLockGuard wlock(_rwlock);
        return _map.erase(key);
    }

    Iterator erase(ConstIterator itr)
    {
        WriteLockGuard wlock(_rwlock);
        return _map.erase(itr);
    }

    Iterator erase(Iterator itr)
    {
        WriteLockGuard wlock(_rwlock);
        return _map.erase(itr);
    }

    void clear() const noexcept
    {
        WriteLockGuard wlock(_rwlock);
        _map.clear();
    }

    MappedType& operator[](const KeyType& key)
    {
        WriteLockGuard wlock(_rwlock);
        return _map[key];
    }

    MappedType& operator[](KeyType&& key)
    {
        WriteLockGuard wlock(_rwlock);
        return _map[std::move(key)];
    }

    const MappedType& Find(const KeyType& key) const noexcept
    {
        ReadLockGuard rlock(_rwlock);
        auto itr = _map.find(key);
        return itr == _map.end() ? _v : itr->second;
    }

private:

    T           _v = T();
    MapType     _map;
    mutable RWLock  _rwlock;
};

}

#endif //MANYSTAR_HASHMAP_H
