//
// Created by zgl on 20/01/2021.
//

#ifndef MANYSTAR_MAP_H
#define MANYSTAR_MAP_H

#include "Tree.h"


namespace manystar {
template<typename Tf, typename Ts>
struct Pair
{
    Pair()
    {
        first = Tf();
        second = Ts();
    }

    Pair(const Tf& f, const Ts& s)
    {
        first = f;
        second = s;
    }

    bool operator < (const Pair& other) const
    {
        return (first < other.first);
    }

    Tf	first;
    Ts	second;
};


template <typename Tk, typename Tv>
class Map
{
public:

    class Iterator
    {
    public:

        Iterator() :_node(nullptr), _tree(nullptr) {}

        bool operator !=(const Iterator& other) const
        {
            return ((_tree != other._tree) || (_node != other._node));
        }

        const Pair<Tk, Tv>& operator *() const
        {
            return _node->key;
        }

        Iterator& operator ++(int)
        {
            _node = _tree->next(_node);
            return *this;
        }

        Iterator operator ++()
        {
            typename Tree<Pair<Tk, Tv>>::Node* cur = _node;
            _node = _tree->next(_node);
            return Iterator(_tree, cur);
        }

        Iterator operator -(unsigned long num) const
        {
            typename Tree<Pair<Tk, Tv>>::Node* cur = _node;
            for (unsigned long count = 0; count < num; count++)
            {
                cur = _tree->prev(cur);
                if (cur == nullptr)
                {
                    return Iterator(_tree, nullptr);
                }
            }

            return Iterator(_tree, cur);
        }

        bool operator ==(const Iterator& other) const
        {
            return ((_tree == other._tree) && (_node == other._node));
        }

    private:

        Iterator(const Tree<Pair<Tk, Tv>>* tree, typename Tree<Pair<Tk, Tv>>::Node* node)
        {
            _node = node;
            _tree = tree;
        }

        typename Tree<Pair<Tk, Tv>>::Node*	_node; // Pointer to the node referenced by the Map Iterator.
        const Tree<Pair<Tk, Tv>>*			_tree; // Pointer to the tree containing the referenced node.

        // The Map class is a friend of Map Iterators.
        friend class Map<Tk, Tv>;
    };

    Iterator begin() const
    {
        return Iterator(&_tree, _tree.begin());
    }

    Iterator end() const
    {
        return Iterator(&_tree, nullptr);
    }

    void erase(Iterator& it)
    {
        _tree.erase(it._node);
    }

    void erase(const Tk& key)
    {
        _tree.erase(Pair<Tk, Tv>(key, Tv()));
    }

    Iterator find(const Tk& key) const
    {
        return Iterator(&_tree, _tree.find(Pair<Tk, Tv>(key, Tv())));
    }

    Iterator insert(const Tk& key, const Tv& data)
    {
        return Iterator(&_tree, _tree.insert(Pair<Tk, Tv>(key, data)));
    }

    unsigned int reserve(unsigned int count)
    {
        return _tree.reserve(count);
    }

private:

    // The key/value pairs are actually stored in a tree.
    Tree<Pair<Tk, Tv>>	_tree;
};

}

#endif //MANYSTAR_MAP_H
