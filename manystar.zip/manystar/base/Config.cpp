//
// Created by zgl on 04/02/2021.
//

#include <algorithm>
#include "Config.h"
#include "../base/Util.h"
#include "../base/ExitCaller.h"


namespace manystar {

Config::Config(const char* name)
{
    if (!parse(name))
    {
        fprintf(stderr, "config file<%s>, parse fail !\n", name);
    }
}

std::string Config::Find(const char *key)
{
    auto it = _confs.find(key);
    if (it != _confs.end())
    {
        return it->second;
    }

    return "";
}

int Config::Find(const char *key, int def)
{
    auto it = _confs.find(key);
    if (it != _confs.end())
    {
        return (int)Util::atoi(it->second.c_str());
    }

    return def;
}

double Config::Find(const char *key, double def)
{
    auto it = _confs.find(key);
    if (it != _confs.end())
    {
        const char* v = it->second.c_str();
        char* end;
        double n = strtod(v, &end);
        return end > v ? n : def;
    }

    return def;
}

bool Config::parse(const char* name)
{
    FILE *file = fopen(name, "r");
    if (!file)
    {
        return false;
    }

    ExitCaller exc([=] { fclose(file); });
    const int MAX_SIZE = 4 * 1024;
    char data[MAX_SIZE];
    while (nullptr != fgets(data, MAX_SIZE, file))
    {
        if (*data == '#')
        {
            continue;
        }

        std::string str(data);
        auto end = std::remove_if(str.begin(), str.end(), [=](const char c) {
            return c == '\\' || c == '"' || c == ' ' || c == '\n';
        });
        str.erase(end, str.end());
        std::vector<std::string> vec;
        Util::split(vec, str, "=");
        if (vec.size() != 2)
        {
            continue;
        }

        _confs.insert(std::pair<std::string, std::string>(vec[0], vec[1]));
    }

    return true;
}

}