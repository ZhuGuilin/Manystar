//
// Created by zgl on 27/01/2021.
//

#ifndef MANYSTAR_FILE_H
#define MANYSTAR_FILE_H

#include <string>

namespace manystar {

class File
{
public:

    File(const std::string& name, const char* mode);
    virtual ~File();

    const std::string& FileName() noexcept;

    long Length();
    void Read(std::string& buf);
    void Write(const char* buf, size_t sz);

private:

    std::string     _name;
    FILE*           _fd = nullptr;
    size_t          _size = 0;
};

}

#endif //MANYSTAR_FILE_H
