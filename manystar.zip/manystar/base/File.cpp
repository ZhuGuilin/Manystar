//
// Created by zgl on 27/01/2021.
//

#include <cstring>
#include <unistd.h>
#include "File.h"
#include "Util.h"


namespace manystar {

File::File(const std::string& name, const char* mode)
:_name(name)
{
    _fd = fopen(name.c_str(), mode);
    if (nullptr == _fd)
    {
        fprintf(stderr, "open file %s failed. msg: %s ignored\n", _name.c_str(), strerror(errno));
    }
}

File::~File()
{
    fclose(_fd);
}

const std::string& File::FileName() noexcept
{
    return _name;
}

long File::Length()
{
    if (nullptr == _fd)
    {
        fprintf(stderr, "Length file %s failed. _fd is null\n", _name.c_str());
        return -1;
    }

    if (0 != _size)
    {
        return (long)_size;
    }
    else
    {
        long curPos = max(ftell(_fd), 0L);
        fseek(_fd, 0, SEEK_END);
        long length = ftell(_fd);
        fseek(_fd, curPos, SEEK_SET);
        return length;
    }
}

void File::Read(std::string& buf)
{
    if (nullptr == _fd)
    {
        fprintf(stderr, "Read file %s failed. _fd is null\n", _name.c_str());
        return;
    }

    fseek(_fd, 0, SEEK_SET);
    const int MAX_SIZE = 4 * 1024;
    char data[MAX_SIZE] = {};
    while (nullptr != fgets(data, MAX_SIZE, _fd))
    {
        buf.append(data);
    }
}

void File::Write(const char* buf, size_t sz)
{
    if (nullptr == _fd)
    {
        fprintf(stderr, "Write file %s failed. _fd is null\n", _name.c_str());
        return;
    }

    fwrite(buf, sz, 1, _fd);
    fflush(_fd);
    _size += sz;
}

}