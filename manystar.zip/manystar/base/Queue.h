//
// Created by zgl on 21/01/2021.
//

#ifndef MANYSTAR_QUEUE_H
#define MANYSTAR_QUEUE_H

#include <queue>
#include "SpinLock.h"


namespace manystar {

template <class T>
class Queue
{
public:

    void push(const T&& v) noexcept
    {
        SpinLockGuard lock(_splock);
        _queue.push(std::move(v));
    }

    T pop() noexcept
    {
        SpinLockGuard lock(_splock);
        if (_queue.empty())
        {
            return T();
        }

        T v = std::move(_queue.front());
        _queue.pop();
        return v;
    }

    std::size_t size() const noexcept
    {
        SpinLockGuard lock(_splock);
        return _queue.size();
    }

    bool empty() const noexcept
    {
        SpinLockGuard lock(_splock);
        return _queue.empty();
    }

private:

    std::queue<T>	 _queue;
    mutable SpinLock _splock;
};

}

#endif //MANYSTAR_QUEUE_H
