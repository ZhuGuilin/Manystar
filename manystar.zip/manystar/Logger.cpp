//
// Created by root on 2021/1/24.
//

#include <stdarg.h>
#include <cstring>
#include "Logger.h"
#include "ServerConf.h"
#include "base/Util.h"
#include "base/File.h"
#include "module/Message.h"
#include "module/ModuleManager.h"


namespace manystar {

static Logger* s_logger = nullptr;
static struct tm* s_tm = nullptr;
static time_t s_tmin = 0;
static const int LOG_BUFF_SIZE = 4 * 1024;
static const char* s_prefixes[] =
 {
        "TRACE",
        "DEBUG",
        "INFO",
        "WARN",
        "ERROR",
        "FATAL"
 };

static const char* s_paths[] =
{
        "socketlog",
        "serverlog"
};


Logger::Logger()
:_level(LL_DEBUG)
{

}

Logger::~Logger()
{

}

Logger& Logger::instance()
{
    if (nullptr == s_logger)
    {
        s_logger = new Logger;
    }

    return *s_logger;
}

void Logger::Setup()
{
    for (int i = 0; i < LT_SIZE; ++i)
    {
        std::string path = ServerConf::instance().LogPath() + "/";
        path += s_paths[i];
        path += Util::system_date();
        path += ".log";

        auto handle = ModuleManager::instance().CreateModule(s_paths[i]);
        ModuleManager::instance().RegisterName(handle);
        auto context = ModuleManager::instance().Find(handle);
        context->userData = std::make_shared<File>(path, "w+");
    }

    auto mill = Util::system_milliseconds();
    time_t sec = (time_t)mill / 1000;
    s_tm = localtime(&sec);
}

void Logger::Output(LOG_LEVEL lv, LOG_TYPE type, const char* fmt, ...)
{
    if (lv < _level) return;
    char buffer[LOG_BUFF_SIZE] = {};
    char* ptr = buffer;
    char* end = buffer + sizeof(buffer);
    DATA data = nullptr;

    auto mill = Util::system_milliseconds();
    time_t sec = (time_t)mill / 1000;
    if (s_tmin != sec / 60)
    {
        localtime_r(&sec, s_tm);
        s_tmin = sec / 60;
    }
    else
    {
        s_tm->tm_sec = sec % 60;
    }
    ptr += snprintf(ptr, end - ptr, "[%02d-%02d %02d:%02d:%02d:%03d][%s] ",
                    s_tm->tm_mon + 1, s_tm->tm_mday, s_tm->tm_hour,
                    s_tm->tm_min, s_tm->tm_sec, int(mill % 1000), s_prefixes[lv]);

    va_list args;
    va_start(args, fmt);
    int len = vsnprintf(ptr, end - ptr, fmt, args);
    va_end(args);

    size_t size = 0;
    if (len >= 0 && len < LOG_BUFF_SIZE)
    {
        ptr += len;
        while (*--ptr == '\n');
        *++ptr = '\n';
        *++ptr = '\0';

        size = strlen(buffer);
        if (size < 128) {
            data = std::make_shared<std::array<char, 128>>();
        } else if (size < 256) {
            data = std::make_shared<std::array<char, 256>>();
        } else if (size < 512) {
            data = std::make_shared<std::array<char, 512>>();
        } else if (size < 1024) {
            data = std::make_shared<std::array<char, 1024>>();
        } else if (size < 2048) {
            data = std::make_shared<std::array<char, 2048>>();
        } else {
            data = std::make_shared<std::array<char, 4096>>();
        }

        memcpy(data.get(), buffer, size);
    }
    else
    {
        perror("Logger::Output vsnprintf error:");
        return;
    }

    auto handle = ModuleManager::instance().Find(type == LT_SERVER ? "serverlog" : "socketlog");
    ModuleManager::instance().Send(0, handle, MT_TEXT, data, size);
}

}