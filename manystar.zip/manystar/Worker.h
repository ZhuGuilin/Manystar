//
// Created by zgl on 04/02/2021.
//

#ifndef MANYSTAR_WORKER_H
#define MANYSTAR_WORKER_H

#include <condition_variable>
#include "base/Queue.h"
#include "module/Module.h"


namespace manystar {

class Worker
{
public:

    using TaskQueue = Queue<uint32_t>;
    using ThreadList = std::vector<std::thread>;
    using ThreadMutex = std::condition_variable;

    static Worker& instance();
    void Setup();

    void AddTask(uint32_t task) noexcept;

    void Quit();
    bool Exit() const noexcept { return _exit.load(); }

private:

    Worker();
    virtual ~Worker();

    void Process(int weight);

    TaskQueue       _tasks;
    ThreadList      _workers;

    std::mutex		_mutex;
    ThreadMutex     _ready;
    AtomicBool      _exit;
};

}

#endif //MANYSTAR_WORKER_H
