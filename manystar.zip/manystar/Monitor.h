//
// Created by zgl on 04/02/2021.
//

#ifndef MANYSTAR_MONITOR_H
#define MANYSTAR_MONITOR_H

#include <atomic>


namespace manystar {

class Monitor
{
public:

    static Monitor& instance();
    void Setup();

    void SleepCounter() noexcept { ++_sleep; }
    void WakeupCounter() noexcept { --_sleep; }

private:

    Monitor();
    virtual ~Monitor();

    std::atomic<uint32_t>   _sleep;     //  wait thread num
};

}

#endif //MANYSTAR_MONITOR_H
