#include "ServerConf.h"
#include "Worker.h"
#include "Monitor.h"
#include "Timer.h"
#include "Logger.h"

#include <iostream>
#include "module/ModuleManager.h"
#include "base/Hashmap.h"
#include "base/Util.h"

int main(int argc, char *argv[])
{
    using namespace manystar;

    //  load server config
    ServerConf::instance().Setup(std::move(Config(argc > 1 ? argv[1] : "config.ini")));

    //  setup monitor
    Monitor::instance().Setup();

    //  setup timer
    Timer::instance().Setup();

    //  setup logger
    Logger::instance().Setup();

#if 0
    Hashmap<std::string, int> hmap;
    std::map<std::string, int> smap;
    Map<std::string, int> zmap;
    std::string syree = "logger_";
    for (int i = 0; i < 1000; ++i) {
        auto str = Util::format("logger_%d", i);
        hmap.insert(std::pair<std::string, int>(str, i));
        smap.insert(std::pair<std::string, int>(str, i));
        zmap.insert(str, i);
    }

    hmap["123"] = 123;


    int vvv = int();
    vvv = hmap.Find("123");
    vvv = hmap.Find("fdfkjghfg");
    hmap.erase("123");
    std::string cmm[5] = {
            "logger_991","logger_942","logger_933","logger_934","logger_885",
    };

    auto start = Util::steady_milliseconds();
    for (int i = 0; i < 1000000; ++i) {
        for (int j = 0; j < 5; ++j) {
            //vvv = hmap[cmm[j]];
            vvv = hmap.Find(cmm[j]);
        }
    }
    std::cout << "5000000 hash map use mil: " << Util::steady_milliseconds() - start << std::endl;

    start = Util::steady_milliseconds();
    for (int i = 0; i < 1000000; ++i) {
        for (int j = 0; j < 5; ++j) {
            vvv = smap[cmm[j]];
        }
    }
    std::cout << "5000000 s map use mil: " << Util::steady_milliseconds() - start << std::endl;

    start = Util::steady_milliseconds();
    for (int i = 0; i < 1000000; ++i) {
        for (int j = 0; j < 5; ++j) {
            vvv = (*zmap.find(cmm[j])).second;
        }
    }
    std::cout << "5000000 z map use mil: " << Util::steady_milliseconds() - start << std::endl;
#endif

    {
        ModuleManager::instance().CreateModule(std::string("test1"));

         ModuleManager::instance().CreateModule("test2");
        /* ModuleManager::instance().CreateModule("test2");
        ModuleManager::instance().CreateModule("test1");
        ModuleManager::instance().CreateModule("test2");
         ModuleManager::instance().CreateModule("test2");
         ModuleManager::instance().CreateModule("test1");
         ModuleManager::instance().CreateModule("test2");
         ModuleManager::instance().CreateModule("test2");
         ModuleManager::instance().CreateModule("test1");
         ModuleManager::instance().CreateModule("test2");
         ModuleManager::instance().CreateModule("test1");
         ModuleManager::instance().CreateModule("test2");
         ModuleManager::instance().CreateModule("test2");
         ModuleManager::instance().CreateModule("test1");
         ModuleManager::instance().CreateModule("test2");
         ModuleManager::instance().CreateModule("test2");
         ModuleManager::instance().CreateModule("test1");
         ModuleManager::instance().CreateModule("test2");
         ModuleManager::instance().CreateModule("test2");
         ModuleManager::instance().CreateModule("test1");
         ModuleManager::instance().CreateModule("test2");
         ModuleManager::instance().CreateModule("test2");
         ModuleManager::instance().CreateModule("test1");
         ModuleManager::instance().CreateModule("test2");
  */
         ModuleManager::instance().CreateModule("test3");
        /* */
    }

    //  setup worker
    Worker::instance().Setup();

    std::cout << "main end" << std::endl;
    return 0;
}
