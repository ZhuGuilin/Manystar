//
// Created by zgl on 04/02/2021.
//

#ifndef MANYSTAR_MODULETEST1_H
#define MANYSTAR_MODULETEST1_H

#include <iostream>
#include "Module.h"
#include "../Timer.h"
#include "../base/Random.h"
#include "../Logger.h"


namespace manystar {

class ModuleTest1 : public Module
{
public:

    ModuleTest1()
    {
        Timer::instance().CreateTimer(200, 4, 0);
    }

    virtual void Callback(ModuleContextPtr context, const Message&& msg)
    {
        std::cout << "ModuleTest1 context: " << context->handle << std::endl;
        //Timer::instance().CreateTimer(Random::instance().rand(20, 200), 2, 0);
        for (int i = 0; i < 20; ++i) {
            info("ModuleTest1 context: %d", context->handle);
            //std::this_thread::sleep_for(std::chrono::microseconds (100));
        }
    }
};

}

#endif //MANYSTAR_MODULETEST1_H
