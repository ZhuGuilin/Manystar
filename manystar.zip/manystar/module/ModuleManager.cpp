//
// Created by zgl on 30/01/2021.
//

#include "ModuleManager.h"
#include "../base/Util.h"
#include "../Worker.h"
#include "../Logger.h"
#include "SocketLog.h"
#include "ServerLog.h"
#include "ModuleTest1.h"
#include "ModuleTest2.h"
#include "ModuleTest3.h"


namespace manystar {

static ModuleManager* s_moduleMgr = nullptr;

inline ModulePtr ModuleManager::ModuleFactory(const std::string& name)
{
    if ("socketlog" == name) {
        return std::make_shared<SocketLog>(name.c_str());
    }
    else if ("serverlog" == name) {
        return std::make_shared<ServerLog>(name.c_str());
    }
    else if ("gate" == name) {
        ;
    }
    else if ("test1" == name) {
        return std::make_shared<ModuleTest1>();
    }
    else if ("test2" == name) {
        return std::make_shared<ModuleTest2>();
    }
    else if ("test3" == name) {
        return std::make_shared<ModuleTest3>();
    }

    fprintf(stderr, "cannot find module name<%s> !\n", name.c_str());
    return nullptr;
}

ModuleManager::ModuleManager()
{
}

ModuleManager::~ModuleManager()
{
}

ModuleManager& ModuleManager::instance()
{
    if (nullptr == s_moduleMgr)
    {
        s_moduleMgr = new ModuleManager;
    }

    return *s_moduleMgr;
}

void ModuleManager::Setup()
{

}

uint32_t ModuleManager::Find(const std::string& name) const noexcept
{
    return _names.Find(name);
}

ModuleContextPtr ModuleManager::Find(uint32_t handle) const noexcept
{
    return _contexts.find(handle);
}

uint32_t ModuleManager::CreateModule(std::string&& name)
{
    auto context = std::make_shared<ModuleContext>();
    context->module = ModuleFactory(Util::Lower(name));
    context->handle = _contexts.insert(context);
    return context->handle;
}

void ModuleManager::RegisterName(uint32_t handle)
{
    auto context = _contexts.find(handle);
    if (nullptr != context)
    {
        _names.insert(StrIntPair(context->module->name, context->handle));
    }
}

void ModuleManager::DestroyModule(uint32_t handle)
{
    auto context = _contexts.find(handle);
    if (nullptr != context)
    {
        _names.erase(context->module->name);
    }
    _contexts.erase(handle);
}

void ModuleManager::Dispatch(uint32_t handle, const Message&& msg)
{
    auto context = _contexts.find(handle);
    if (nullptr == context)
    {
        fprintf(stderr, "Dispatch cannot find module handle<%d> !\n", handle);
        return;
    }

    context->msges.push(std::move(msg));
    if (!context->inGlobal.exchange(true))
    {   //  push global message queue
        Worker::instance().AddTask(context->handle);
    }
}

uint32_t ModuleManager::Send(uint32_t source,
                             uint32_t destination,
                             MSG_TYPE type,
                             DATA data,
                             uint32_t size)
{
    auto from = _contexts.find(source);
    Message msg;
    msg.source = source;
    msg.session = nullptr == from ? 0 : from->Session();
    msg.data = data;
    msg.expend = (size & MESSAGE_TYPE_MASK) | ((uint32_t)type << MESSAGE_TYPE_SHIFT);

    Dispatch(destination, std::move(msg));
    return msg.session;
}

}