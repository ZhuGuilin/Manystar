//
// Created by zgl on 04/02/2021.
//

#ifndef MANYSTAR_MODULETEST2_H
#define MANYSTAR_MODULETEST2_H

#include <iostream>
#include "Module.h"
#include "../Timer.h"


namespace manystar {

    class ModuleTest2 : public Module
    {
    public:

        ModuleTest2()
        {
            Timer::instance().CreateTimer(200, 3, 0);
        }

        virtual void Callback(ModuleContextPtr context, const Message&& msg)
        {
            std::cout << "ModuleTest2 context: " << context->handle << std::endl;
            //Timer::instance().CreateTimer(Random::instance().rand(30, 120), 1, 0);
            for (int i = 0; i < 20; ++i) {
                warn("ModuleTest2 context: %s", "a43s35ee34we234tt39g09g54t46546@#$@#5#$ty%$67^7%$^");
                //std::this_thread::sleep_for(std::chrono::microseconds (100));
            }
        }
    };

}

#endif //MANYSTAR_MODULETEST2_H
