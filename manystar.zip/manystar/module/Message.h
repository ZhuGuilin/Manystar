//
// Created by zgl on 30/01/2021.
//

#ifndef MANYSTAR_MESSAGE_H
#define MANYSTAR_MESSAGE_H

#include "../base/Queue.h"

// type is encoding in Message.expend high 8bit
#define MESSAGE_TYPE_MASK (uint32_t(~0) >> 8)
#define MESSAGE_TYPE_SHIFT 24

namespace manystar {

using DATA = std::shared_ptr<void>;
using Mqueue = Queue<struct Message>;

enum MSG_TYPE
{
    MT_TEXT = 0,
    MT_RESPONSE,
    MT_MULTICAST,
    MT_CLIENT,
    MT_SYSTEM,
    MT_SOCKET
};

struct Message
{
    uint32_t    source;
    uint32_t    session;
    uint32_t    expend;
    DATA        data;

    Message()
    :source(0)
    ,session(0)
    ,expend(0)
    ,data(nullptr)
    { }
};

}

#endif //MANYSTAR_MESSAGE_H
