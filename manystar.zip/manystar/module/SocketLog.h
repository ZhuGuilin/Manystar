//
// Created by root on 2021/2/12.
//

#ifndef MANYSTAR_SOCKETLOG_H
#define MANYSTAR_SOCKETLOG_H

#include "Module.h"
#include "../base/File.h"


namespace manystar {

class SocketLog : public Module
{
public:

    SocketLog(const char* n)
    {
        name = n;
    }

    virtual ~SocketLog()
    {

    }

    virtual void Callback(ModuleContextPtr context, const Message&& msg)
    {
        auto file = static_cast<File*>(context->userData.get());
        if (nullptr != file)
        {
            file->Write((const char*)msg.data.get(), msg.expend & MESSAGE_TYPE_MASK);
        }
    }
};

}

#endif //MANYSTAR_SOCKETLOG_H
