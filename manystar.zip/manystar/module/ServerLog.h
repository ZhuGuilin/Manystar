//
// Created by root on 2021/2/15.
//

#ifndef MANYSTAR_SERVERLOG_H
#define MANYSTAR_SERVERLOG_H

#include "Module.h"
#include "ModuleManager.h"
#include "../base/File.h"


namespace manystar {

class ServerLog : public Module
{
public:

    ServerLog(const char* n)
    {
        name = n;
    }

    virtual ~ServerLog()
    {

    }

    virtual void Callback(ModuleContextPtr context, const Message&& msg)
    {
        auto file = static_cast<File*>(context->userData.get());
        if (nullptr != file)
        {
            file->Write((const char*)msg.data.get(), msg.expend & MESSAGE_TYPE_MASK);
        }
    }
};

}

#endif //MANYSTAR_SERVERLOG_H
