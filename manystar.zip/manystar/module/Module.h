//
// Created by zgl on 02/02/2021.
//

#ifndef MANYSTAR_MODULE_H
#define MANYSTAR_MODULE_H

#include <string>
#include "Message.h"

namespace manystar {

using ModulePtr = std::shared_ptr<struct Module>;
using ModuleContextPtr = std::shared_ptr<struct ModuleContext>;
using AtomicBool = std::atomic<bool>;

struct Module
{
    std::string name;

    virtual void Callback(ModuleContextPtr context, const Message&& msg)
    {
    }
};

struct ModuleContext final
{
    uint32_t    handle;
    uint32_t    session;
    uint32_t    msgCount;

    bool        profile;
    uint64_t    cpuCost;

    DATA        userData;
    ModulePtr   module;
    Mqueue      msges;

    AtomicBool  inGlobal;

    ModuleContext()
    :handle(0)
    ,session(0)
    ,msgCount(0)
    ,cpuCost(0)
    ,profile(false)
    ,inGlobal(false)
    ,userData(nullptr)
    ,module(nullptr)
    { }

    inline uint32_t Session()
    {
        return ++session == 0 ? 1 : session;
    }
};

}

#endif //MANYSTAR_MODULE_H
