//
// Created by zgl on 06/02/2021.
//

#ifndef MANYSTAR_MODULETEST3_H
#define MANYSTAR_MODULETEST3_H

#include <iostream>
#include "Module.h"
#include "../Timer.h"
#include "../Worker.h"
#include "../Logger.h"


namespace manystar {

    class ModuleTest3 : public Module
    {
    public:

        ModuleTest3()
        {
            Timer::instance().CreateTimer(400, 5, 0);
        }

        virtual void Callback(ModuleContextPtr context, const Message&& msg)
        {
            if (msg.session == 0)
            {
                std::cout << "ModuleTest3 context: " << context->handle << std::endl;
                //Timer::instance().CreateTimer(Random::instance().rand(30, 120), 1, 0);
                error("ModuleTest3 context: %d", context->handle);
                Timer::instance().CreateTimer(100, context->handle, context->Session());
            }
            else if (msg.session == 1)
            {
                Worker::instance().Quit();
            }
        }
    };

}

#endif //MANYSTAR_MODULETEST3_H
