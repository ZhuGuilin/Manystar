//
// Created by zgl on 30/01/2021.
//

#ifndef MANYSTAR_MODULEMANAGER_H
#define MANYSTAR_MODULEMANAGER_H

#include <unordered_map>
#include "Module.h"
#include "../base/HandleDict.h"
#include "../base/Hashmap.h"


namespace manystar {

class ModuleManager
{
public:

    using ContextMap = HandleDict<ModuleContextPtr>;
    using HandleName = Hashmap<std::string, uint32_t>;
    using StrIntPair = std::pair<std::string, uint32_t>;

    static ModuleManager& instance();
    void Setup();

    uint32_t Find(const std::string& name) const noexcept;
    ModuleContextPtr Find(uint32_t handle) const noexcept;

    uint32_t CreateModule(std::string&& name);
    void RegisterName(uint32_t handle);
    void DestroyModule(uint32_t handle);

    void Dispatch(uint32_t handle, const Message&& msg);
    uint32_t Send(uint32_t source, uint32_t destination, MSG_TYPE type, DATA data, uint32_t size);

private:

    ModuleManager();
    virtual ~ModuleManager();

    inline ModulePtr ModuleFactory(const std::string& name);

    ContextMap      _contexts;
    HandleName      _names;
};

}

#endif //MANYSTAR_MODULEMANAGER_H
