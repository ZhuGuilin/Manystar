//
// Created by zgl on 04/02/2021.
//

#include "Monitor.h"


namespace manystar {

static Monitor* s_monitor = nullptr;

Monitor::Monitor()
:_sleep(0)
{

}

Monitor::~Monitor()
{

}

Monitor& Monitor::instance()
{
    if (nullptr == s_monitor)
    {
        s_monitor = new Monitor;
    }

    return *s_monitor;
}

void Monitor::Setup()
{

}

}