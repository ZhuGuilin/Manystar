//
// Created by zgl on 04/02/2021.
//

#ifndef MANYSTAR_SERVERCONF_H
#define MANYSTAR_SERVERCONF_H

#include "base/Config.h"


namespace manystar {

class ServerConf
{
public:

    static ServerConf& instance()
    {
        static ServerConf s_conf;
        return s_conf;
    }

    void Setup(Config&& conf)
    {
        _address = conf.Find("address");
        _logpath = conf.Find("logpath");
        _redisIp = conf.Find("redis_ip");
        _redisPort = conf.Find("redis_port");
        _thread = conf.Find("thread", 2);
        _profile = conf.Find("profile", 0) != 0;
    }

    const std::string& Address() noexcept
    {
        return _address;
    }

    const std::string& LogPath() noexcept
    {
        return _logpath;
    }

    const std::string& RedisIp() noexcept
    {
        return _redisIp;
    }

    const std::string& RedisPort() noexcept
    {
        return _redisPort;
    }

    uint32_t ThreadNum() noexcept
    {
        return _thread;
    }

    bool Profile() noexcept
    {
        return _profile;
    }

private:

    ServerConf() {}
    virtual ~ServerConf() {}

    std::string     _address;
    std::string     _logpath;
    std::string     _redisIp;
    std::string     _redisPort;

    uint32_t        _thread;
    bool            _profile;
};

}

#endif //MANYSTAR_SERVERCONF_H
