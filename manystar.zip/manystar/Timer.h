//
// Created by zgl on 20/01/2021.
//

#ifndef MANYSTAR_TIMER_H
#define MANYSTAR_TIMER_H

#include <stdint.h>
#include "base/Map.h"
#include "base/SpinLock.h"


namespace manystar {

class Timer
{
public:

    typedef uint32_t TimerId;
    using AtomicTimerID = std::atomic<uint32_t>;

    enum TIMER_STATUS
    {
        TS_NORMAL = 1 << 1,
        TS_CANCEL = 1 << 2,
        TS_LOOP   = 1 << 3
    };

    struct TimerNode
    {
        TimerId     timerId;
        uint32_t    expire;
        uint32_t    expend;
        uint32_t    handle;
        uint32_t    session;
        TimerNode*  next;

        TimerNode()
        :timerId(0)
        ,expire(0)
        ,expend(0)
        ,handle(0)
        ,session(0)
        ,next(nullptr)
        { }
    };
    typedef Map<int, TimerNode*>	TimerMap;

    struct TimerList
    {
        TimerNode	head;
        TimerNode*	tail;

        TimerList() :tail(nullptr) {}
    };

    static Timer& instance();
    void Setup();

    TimerId CreateTimer(int time, uint32_t handle, uint32_t session, bool loop = false);
    void CancelTimer(TimerId id);

private:

    Timer();
    virtual ~Timer();

    inline void Tick();
    inline TimerNode* Clear(TimerList* list)
    {
        TimerNode* node = list->head.next;
        list->head.next = nullptr;
        list->tail = &(list->head);
        return node;
    }

    inline void Link(TimerList* list, TimerNode* node)
    {
        list->tail->next = node;
        list->tail = node;
        node->next = nullptr;
    }

    void AddNode(TimerNode* node);
    void Move(int lv, int idx);
    void Execute();
    void Shift();
    void Dispatch(TimerNode* node);

    static const int TIME_NEAR_BITS = 8;
    static const int TIME_LEVEL_BITS = 6;
    static const int TIME_NEAR_SIZE = (1 << TIME_NEAR_BITS);
    static const int TIME_LEVEL_SIZE = (1 << TIME_LEVEL_BITS);
    static const int TIME_NEAR_MASK = (TIME_NEAR_SIZE - 1);
    static const int TIME_LEVEL_MASK = (TIME_LEVEL_SIZE - 1);

    TimerList		_near[TIME_NEAR_SIZE];
    TimerList		_tvec[4][TIME_LEVEL_SIZE];

    AtomicTimerID	_timerID;
    uint32_t		_time;
    uint64_t		_current;
    uint64_t		_point;

    TimerMap		_timers;
    SpinLock		_splock;

    std::thread     _thread;
};

}

#endif //MANYSTAR_TIMER_H
