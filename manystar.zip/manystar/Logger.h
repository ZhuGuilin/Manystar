//
// Created by root on 2021/1/24.
//

#ifndef MANYSTAR_LOGGER_H
#define MANYSTAR_LOGGER_H

#include <stdio.h>


namespace manystar {

class Logger
{
public:

    enum LOG_LEVEL
    {
        LL_TRACE,
        LL_DEBUG,
        LL_INFO,
        LL_WARN,
        LL_ERROR,
        LL_FATAL
    };

    enum LOG_TYPE
    {
        LT_SOCKET,
        LT_SERVER,
        LT_SIZE
    };

    static Logger& instance();
    void Setup();

    void Level(LOG_LEVEL level) { _level = level; }
    LOG_LEVEL Level() const { return _level; }

    void Output(LOG_LEVEL lv, LOG_TYPE type, const char* fmt, ...);

private:

    Logger();
    virtual ~Logger();

    LOG_LEVEL   _level;
};

#define trace_s(...) Logger::instance().Output(Logger::LL_TRACE, Logger::LT_SOCKET, __VA_ARGS__)
#define debug_s(...) Logger::instance().Output(Logger::LL_DEBUG, Logger::LT_SOCKET, __VA_ARGS__)
#define info_s(...) Logger::instance().Output(Logger::LL_INFO, Logger::LT_SOCKET, __VA_ARGS__)
#define warn_s(...) Logger::instance().Output(Logger::LL_WARN, Logger::LT_SOCKET, __VA_ARGS__)
#define error_s(...) Logger::instance().Output(Logger::LL_ERROR, Logger::LT_SOCKET, __VA_ARGS__)
#define fatal_s(...) Logger::instance().Output(Logger::LL_FATAL, Logger::LT_SOCKET, __VA_ARGS__)
#define fatalif_s(b, ...)                                                                 \
    do {                                                                                \
        if ((b)) {                                                                      \
            Logger::instance().Output(Logger::LL_FATAL, Logger::LT_SOCKET, __VA_ARGS__);\
        }                                                                               \
    } while (0)

#define trace(...) Logger::instance().Output(Logger::LL_TRACE, Logger::LT_SERVER, __VA_ARGS__)
#define debug(...) Logger::instance().Output(Logger::LL_DEBUG, Logger::LT_SERVER, __VA_ARGS__)
#define info(...) Logger::instance().Output(Logger::LL_INFO, Logger::LT_SERVER, __VA_ARGS__)
#define warn(...) Logger::instance().Output(Logger::LL_WARN, Logger::LT_SERVER, __VA_ARGS__)
#define error(...) Logger::instance().Output(Logger::LL_ERROR, Logger::LT_SERVER, __VA_ARGS__)
#define fatal(...) Logger::instance().Output(Logger::LL_FATAL, Logger::LT_SERVER, __VA_ARGS__)

#define warnif(b, ...)                                                                  \
    do {                                                                                \
        if ((b)) {                                                                      \
            Logger::instance().Output(Logger::LL_WARN, Logger::LT_SERVER, __VA_ARGS__); \
        }                                                                               \
    } while (0)

#define errorif(b, ...)                                                                 \
    do {                                                                                \
        if ((b)) {                                                                      \
            Logger::instance().Output(Logger::LL_ERROR, Logger::LT_SERVER, __VA_ARGS__);\
        }                                                                               \
    } while (0)

#define fatalif(b, ...)                                                                 \
    do {                                                                                \
        if ((b)) {                                                                      \
            Logger::instance().Output(Logger::LL_FATAL, Logger::LT_SERVER, __VA_ARGS__);\
        }                                                                               \
    } while (0)

}

#endif //MANYSTAR_LOGGER_H
