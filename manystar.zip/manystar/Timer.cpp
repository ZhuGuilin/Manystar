//
// Created by zgl on 20/01/2021.
//

#include "Timer.h"
#include "base/Util.h"
#include "base/SimpleMemoryPool.h"
#include "module/Message.h"
#include "module/ModuleManager.h"
#include "Worker.h"

#define TIMER_EXPEND_MASK   (uint32_t(~0) << 8)
#define SERVER_TIME (Util::steady_milliseconds() / 10)


namespace manystar {

static Timer* s_Timer = nullptr;
static SimpleMemoryPool<Timer::TimerNode>	s_timerNodePool(128);

Timer::Timer()
: _timerID(0)
, _time(0)
, _current(0)
, _point(0)
{

}

Timer::~Timer()
{
    for (auto& it : _timers)
    {
        s_timerNodePool.free(it.second);
    }
}

Timer& Timer::instance()
{
    if (nullptr == s_Timer)
    {
        s_Timer = new Timer;
    }

    return *s_Timer;
}

void Timer::Setup()
{
    for (int i = 0; i < TIME_NEAR_SIZE; i++)
    {
        Clear(&_near[i]);
    }

    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < TIME_LEVEL_SIZE; j++)
        {
            Clear(&_tvec[i][j]);
        }
    }

    _point = SERVER_TIME;
    std::thread t([=] {
        const auto SLEEP_VALUE = std::chrono::milliseconds (1);
        auto& worker = Worker::instance();
        while(!worker.Exit())
        {
            Tick();
            std::this_thread::sleep_for(SLEEP_VALUE);
        }
    });
    _thread.swap(t);
}

inline void Timer::Tick()
{
    uint64_t st = SERVER_TIME;
    if (st < _point)
    {
        printf("time diff error: change from %lu to %lu\n", st, _point);
        _point = st;
    }
    else if (st != _point)
    {
        uint32_t diff = (uint32_t)(st - _point);
        _point = st;
        _current += diff;
        for (uint32_t i = 0; i < diff; i++)
        {
            SpinLockGuard lock(_splock);

            Execute();

            Shift();

            Execute();
        }
    }
}

void Timer::AddNode(TimerNode* node)
{
    uint32_t time = node->expire;
    if ((time | TIME_NEAR_MASK) == (_time | TIME_NEAR_MASK))
    {
        Link(&_near[time & TIME_NEAR_MASK], node);
    }
    else
    {
        int i;
        uint32_t mask = TIME_NEAR_SIZE << TIME_LEVEL_BITS;
        for (i = 0; i < 3; i++)
        {
            if ((time | (mask - 1)) == (_time | (mask - 1)))
            {
                break;
            }
            mask <<= TIME_LEVEL_BITS;
        }

        Link(&_tvec[i][((time >> (TIME_NEAR_BITS + i * TIME_LEVEL_BITS)) & TIME_LEVEL_MASK)], node);
    }
}

Timer::TimerId Timer::CreateTimer(int time, uint32_t handle, uint32_t session, bool loop/* = false*/)
{
    if (time <= 0)
    {
        Message msg;
        msg.session = session;
        msg.expend = MT_RESPONSE << 24;
        ModuleManager::instance().Dispatch(handle, std::move(msg));
        return 0;
    }
    else
    {
        auto node = s_timerNodePool.malloc();
        node->timerId = ++_timerID;
        node->expire = _time + time;
        node->handle = handle;
        node->session = session;
        node->expend = (time << 8) | (loop ? TIMER_STATUS::TS_LOOP : TIMER_STATUS::TS_NORMAL);

        SpinLockGuard lock(_splock);
        AddNode(node);
        _timers.insert(node->timerId, node);
        return node->timerId;
    }
}

void Timer::CancelTimer(TimerId id)
{
    SpinLockGuard lock(_splock);

    auto itr = _timers.find(id);
    if (itr != _timers.end())
    {
        (*itr).second->expend = ((*itr).second->expend & TIMER_EXPEND_MASK) | TIMER_STATUS::TS_CANCEL;
    }
}

void Timer::Move(int lv, int idx)
{
    TimerNode* node = Clear(&_tvec[lv][idx]);
    while (node)
    {
        TimerNode* temp = node->next;
        AddNode(node);
        node = temp;
    }
}

void Timer::Execute()
{
    int idx = _time & TIME_NEAR_MASK;
    while (_near[idx].head.next)
    {
        TimerNode* node = Clear(&_near[idx]);
        _splock.unlock();

        // dispatch don't need lock
        Dispatch(node);

        _splock.lock();
    }
}

void Timer::Shift()
{
    int mask = TIME_NEAR_SIZE;
    uint32_t t = ++_time;
    if (t == 0)
    {
        Move(3, 0);
    }
    else
    {
        uint32_t time = t >> TIME_NEAR_BITS;
        int level = 0;
        while ((t & (mask - 1)) == 0)
        {
            int idx = time & TIME_LEVEL_MASK;
            if (idx != 0)
            {
                Move(level, idx);
                break;
            }

            mask <<= TIME_LEVEL_BITS;
            time >>= TIME_LEVEL_BITS;
            ++level;
        }
    }
}

void Timer::Dispatch(TimerNode* node)
{
    do {
        if (!(node->expend & TIMER_STATUS::TS_CANCEL))
        {
            Message msg;
            msg.session = node->session;
            msg.expend = MT_RESPONSE << 24;
            ModuleManager::instance().Dispatch(node->handle, std::move(msg));

            if (node->expend & TIMER_STATUS::TS_LOOP)
            {
                node->expire = _time + (node->expend >> 8);

                SpinLockGuard lock(_splock);
                AddNode(node);
                node = node->next;
                continue;
            }
        }

        auto itr = _timers.find(node->timerId);
        if (itr != _timers.end())
        {
            _timers.erase(itr);
        }

        TimerNode* temp = node;
        node = node->next;
        s_timerNodePool.free(temp);
    } while (node);
}

}